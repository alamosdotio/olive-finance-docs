# Liquidity Pool UI walkthrough

![image.png](image.png)

1. Solana Liquidity Pool: This is the name of the investment pool you are looking at.
2.  APY Info:  Shows the **annual return percentage** you might earn by investing. The date shows when this was last updated.
3. Solana Pool: Explains what this pool does: it makes money by selling **covered calls** and **cash secured puts** (types of crypto options trading strategies).
4. Total Value Locked: Tells how much money is currently in the pool. "AUM" stands for **Assets Under Management**.
5. Graph: Shows a **visual representation** (like price or performance) of the pool over time.
6. Liquidity Allocation Title:  This section explains **how the money in the pool is divided** between different tokens (types of cryptocurrencies).
7. Token Breakdown: 
    
    Shows details for each token in the pool:
    
    - **Token name and symbol (e.g., SOL, USDC)**
    - **Pool size** (how much of that token is in the pool)
    - **Current % weight** of the token in the pool
    - **Target % weight** (goal)
    - **Utilization** (how much is being used)
8. Buy/Sell Buttons: Buttons to either **Buy into** or **Sell out of** the pool.
9. Pay Section: Choose **which token** and **how much** you want to use to invest.
10. Token Price and Supply:
Shows the current **price per pool token** and how many tokens exist in total.
11. Final Buy Button: Click this to **confirm your purchase** and invest in the pool.